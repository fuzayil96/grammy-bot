function getBalance(ctx) {
  function setInfo(info) {
    const data = info + 15;
  }

  function getPartnerBalance() {
    setInfo(info);
  }
}
